/**
 * @author Hovig Ohannessian
 * email   hovigg@hotmail.com
 * date	   15-Apr-15
 */

package com.ibm.bluemixsparkled;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.List;
import java.util.Properties;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import bolts.Continuation;
import bolts.Task;

import com.ibm.mobile.services.core.IBMBluemix;
import com.ibm.mobile.services.push.IBMPush;
import com.ibm.mobile.services.push.IBMPushNotificationListener;
import com.ibm.mobile.services.push.IBMSimplePushNotification;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
@SuppressLint("NewApi")
public class MainActivity extends Activity {
	ImageButton onButton;
	ImageButton offButton;
	private TextView txtVResult;
	int led;
	
	private IBMPush push = null;
	private IBMPushNotificationListener notificationListener = null;
	private List<String> allTags;
	private List<String> subscribedTags;
	
	//update info in sparkled.properties with proper info from Bluemix Mobile option
	private static final String CLASS_NAME = MainActivity.class.getSimpleName();
    private static final String APP_ID = "applicationID";
    private static final String APP_SECRET = "applicationSecret";
    private static final String APP_ROUTE = "applicationRoute";
    private static final String PROPS_FILE = "sparkled.properties";
    
    NotificationManager nm;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		onButton = (ImageButton) findViewById(R.id.onButton);
		offButton = (ImageButton) findViewById(R.id.offButton);
		txtVResult = (TextView) findViewById(R.id.display);
		
		Properties props = new java.util.Properties();
        Context context = getApplicationContext();
        try {
            AssetManager assetManager = context.getAssets();
            props.load(assetManager.open(PROPS_FILE));
            Log.i(CLASS_NAME, "Found configuration file: " + PROPS_FILE);
        } catch (FileNotFoundException e) {
            Log.e(CLASS_NAME, "The sparkled.properties file was not found.", e);
        } catch (IOException e) {
            Log.e(CLASS_NAME, "The sparkled.properties file could not be read properly.", e);
        }
        Log.i(CLASS_NAME, "Application ID is: " + props.getProperty(APP_ID));
		IBMBluemix.initialize(this, props.getProperty(APP_ID), props.getProperty(APP_SECRET), props.getProperty(APP_ROUTE));
		
		 View.OnClickListener postListenerOn = new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 // Post 1,HIGH to spark core
                 new PostClientControlLed().execute("HIGH");
//                 MainActivity.this.notify("Spark LED is ON");
                 setLedStatus(1);
             }
         };
         onButton.setOnClickListener(postListenerOn);
         
         View.OnClickListener postListenerOff = new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 // Post 0,LOW to spark core
                 new PostClientControlLed().execute("LOW");
//                 MainActivity.this.notify("Spark LED is OFF");
                 setLedStatus(0);
             }
         };
         offButton.setOnClickListener(postListenerOff);
		
         push = IBMPush.initializeService();
 		 push.register("DemoDevice", "DemoUser").continueWith(new Continuation<String, Void>() {

             @Override
             public Void then(Task<String> task) throws Exception {

            	  if (task.isFaulted()) {
                      updateTextView("Error registering with Push Service. " + task.getError().getMessage() + "\n"
                              + "Push notifications will not be received.");
                  } else {
                      updateTextView("Device is registered with Push Service" + "\n" + "Device Id : " + task.getResult());


                      displayTagSubscriptions().continueWith(new Continuation<Void, Void>() {

                          @Override
                          public Void then(Task<Void> task) throws Exception {
                              subscribeToTag();
                              return null;
                          }

                      });
                  }
                 return null;
             }
         });
 		displayTags();
 		notificationListener = new IBMPushNotificationListener() {

			@Override
			public void onReceive(final IBMSimplePushNotification message) {
				showSimplePushMessage(message);

			}

		};
	}
	
	public void setLedStatus(int i) {
		led = i;
	}
	
	public int getLedStatus() {
		return led;
	}

	@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
	@SuppressLint("NewApi")
	private void notify(String methodName) {
	    String name = this.getClass().getName();
	    Notification noti = new Notification.Builder(this)
	        .setContentTitle(methodName).setAutoCancel(true)
	        .setSmallIcon(R.drawable.ic_launcher)
	        .setContentText(name).build();
	    NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
	    notificationManager.notify((int) System.currentTimeMillis(), noti);
	  }
	
	@Override
	protected void onResume() {
		super.onResume();

		if (push != null) {
			push.listen(notificationListener);
		}
	}

	@Override
	protected void onPause() {
		super.onPause();

		if (push != null) {
			push.hold();
		}
	}
	
	void updateTextView(final String message) {
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				txtVResult.append("\n"+ message + "\n");
			}
		});
	}
	
	void showSimplePushMessage(final IBMSimplePushNotification message) {
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setMessage("Notification Received : "
						+ message.toString());
				builder.setCancelable(true);
				builder.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int s) {
							}
						});

				AlertDialog dialog = builder.create();
				dialog.show();
			}
		});
	}
	
	private void displayTags() {
		push.getTags().continueWith(new Continuation<List<String>,Void>() { 
			
			@Override
			public Void then(Task<List<String>> task) throws Exception {
				if(task.isFaulted()) {
					updateTextView("Error getting tags. " + task.getError().getMessage());
					return null;
				}
				List<String> tags = task.getResult();
				updateTextView("Retrieved Tags : " + tags);
				allTags = tags;
				return null;
			}
		});		
	}
	
	private Task<Void> displayTagSubscriptions() {
		
		return push.getSubscriptions().continueWith(new Continuation<List<String>,Void>() { 
			
			@Override
			public Void then(Task<List<String>> task) throws Exception {
				if(task.isFaulted()) {
					updateTextView("Error getting subscriptions.. " + task.getError().getMessage());
					return null;
				}
				List<String> tags = task.getResult();
				updateTextView("Retrieved subscriptions : " + tags);
				subscribedTags = tags;
				return null;
			}
		});			
	}

	private void subscribeToTag() {
		
		if ((subscribedTags != null && subscribedTags.size() == 0) && (allTags != null && allTags.size() != 0)) {
			push.subscribe(allTags.get(0)).continueWith(new Continuation<String, Void>() {

                @Override
                public Void then(Task<String> task) throws Exception {
                    if (task.isFaulted()) {
                        updateTextView("Error subscribing to Tag.."
                                + task.getError().getMessage());
                        return null;
                    }                    
                    updateTextView("Successfully Subscribed to Tag "+task.getResult());
                    
                    return null;
                }
            });
			
		} else {			
			updateTextView("Not subscribing to any more tags.");			
		}
	}

    class PostClientControlLed extends AsyncTask<String, Void, String> {
        public String doInBackground(String... IO) {

            String io = new String(IO[0]);
            URL url;

            try {
            	//get your device name and access token from https://build.spark.io that you have your sparkled.ino compiled
                url = new URL("https://api.spark.io/v1/devices/YOUR_DEVICE_NAME/updateLED?access_token=ACCESSTOKEN"); 
                String param = null;
                if(getLedStatus() == 1) {
                	param = "params=1,"+io;
                } else {
                	param = "params=0,"+io;
                }
                Log.d(null, "param:" + param);

                // Open a connection using HttpURLConnection
                HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
                con.setReadTimeout(7000);
                con.setConnectTimeout(7000);
                con.setDoOutput(true);
                con.setDoInput(true);
                con.setInstanceFollowRedirects(false);
                con.setRequestMethod("POST");
                con.setFixedLengthStreamingMode(param.getBytes().length);
                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // Send out param value
                PrintWriter out = new PrintWriter(con.getOutputStream());
                out.print(param);
                out.close();

                con.connect();

                BufferedReader in = null;
                if (con.getResponseCode() != 200) {
                    in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
                    Log.d(null, "!=200: " + in);
                } else {
                    in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    if(getLedStatus() == 1) {
                    	MainActivity.this.notify("BMX SparkLED is ON");
                    } else {
                    	MainActivity.this.notify("BMX SparkLED is OFF");
                    }
                    Log.d(null, "POST request send successful: " + in);
                };
            } catch (Exception e) {
                Log.d(null, "Exception");
                e.printStackTrace();
                return null;
            }
            return null;
        }
    }
}
